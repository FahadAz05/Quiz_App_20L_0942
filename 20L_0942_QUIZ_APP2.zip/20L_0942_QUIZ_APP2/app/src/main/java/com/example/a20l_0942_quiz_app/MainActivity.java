package com.example.a20l_0942_quiz_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ImageView ivLogo;//logo in the splash screen.
    Animation fadding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ivLogo = findViewById(R.id.img1);
        fadding = AnimationUtils.loadAnimation(this, R.anim.fadding);
        ivLogo.setAnimation(fadding);
        new Handler()
                .postDelayed(()->{
                    // Starts the Home activity
                    startActivity(new Intent(MainActivity.this, activity_start_screen.class));
                    finish(); //Closes MainActivity so the user cannot return to it using the back button
                }, 5000);
    }

}