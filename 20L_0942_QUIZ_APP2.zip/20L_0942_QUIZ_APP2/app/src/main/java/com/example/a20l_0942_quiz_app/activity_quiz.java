package com.example.a20l_0942_quiz_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_quiz extends AppCompatActivity {
    private TextView tvQuestion, tvPageCount;
    private RadioGroup radioGroup;
    private RadioButton rbOpt1, rbOpt2, rbOpt3, rbOpt4;
    private Button btnNext, btnPrev;
    private QuizBackend quizBackend;
    private int score = 0;
    private String username = "Guest"; // Default username if not provided

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_quiz_screen);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Retrieve username from Intent
        username = getIntent().getStringExtra("username");
        if (username == null || username.isEmpty()) {
            username = "Guest"; // Fallback default value
        }

        tvQuestion = findViewById(R.id.tvquestions);
        tvPageCount = findViewById(R.id.tvpgcount);
        radioGroup = findViewById(R.id.radioGroup);
        rbOpt1 = findViewById(R.id.rbopt1);
        rbOpt2 = findViewById(R.id.rbopt2);
        rbOpt3 = findViewById(R.id.rbopt3);
        rbOpt4 = findViewById(R.id.rbopt4);
        btnNext = findViewById(R.id.btnnext);
        btnPrev = findViewById(R.id.btnprev);

        quizBackend = new QuizBackend();
        updateQuestionUI();

        btnNext.setOnClickListener(v -> {
            checkAnswer();

            if (quizBackend.getCurrentIndex() == quizBackend.getTotalQuestions() - 1) {
                // Last question: Start activity_result and pass the score and username
                Intent intent = new Intent(activity_quiz.this, activity_result.class);
                intent.putExtra("final_score", score);
                intent.putExtra("username", username);
                startActivity(intent);
                finish(); // Close the quiz activity
            } else {
                if (quizBackend.nextQuestion()) {
                    updateQuestionUI();
                }
            }
        });

        btnPrev.setOnClickListener(v -> {
            if (quizBackend.prevQuestion()) {
                updateQuestionUI();
            }
        });
    }

    private void updateQuestionUI() {
        Question currentQuestion = quizBackend.getCurrentQuestion();
        tvQuestion.setText(currentQuestion.getQuestionText());
        rbOpt1.setText(currentQuestion.getOptions()[0]);
        rbOpt2.setText(currentQuestion.getOptions()[1]);
        rbOpt3.setText(currentQuestion.getOptions()[2]);
        rbOpt4.setText(currentQuestion.getOptions()[3]);
        tvPageCount.setText((quizBackend.getCurrentIndex() + 1) + "/" + quizBackend.getTotalQuestions());
        radioGroup.clearCheck();

        if (quizBackend.getCurrentIndex() == quizBackend.getTotalQuestions() - 1) {
            btnNext.setText("Finish");
        } else {
            btnNext.setText("Next");
        }
    }

    private void checkAnswer() {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        if (selectedId == -1) return; // No option selected

        int selectedOption = -1;
        if (selectedId == R.id.rbopt1) selectedOption = 0;
        else if (selectedId == R.id.rbopt2) selectedOption = 1;
        else if (selectedId == R.id.rbopt3) selectedOption = 2;
        else if (selectedId == R.id.rbopt4) selectedOption = 3;

        if (quizBackend.checkAnswer(selectedOption)) {
            score += 10; // Increment score only if the answer is correct
        }
    }
}
