package com.example.a20l_0942_quiz_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class activity_result extends AppCompatActivity {
    private String username = "Guest"; // Default username if not provided
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvScore = findViewById(R.id.tvScore);
        TextView tvUsername2 = findViewById(R.id.tvUsername2);
        Button btnRestart = findViewById(R.id.btnRestart);
        Button btnShare = findViewById(R.id.btnShare); // Link with XML button

        // Get score and username from intent
        score = getIntent().getIntExtra("final_score", 0);
        username = getIntent().getStringExtra("username");
        if (username == null || username.isEmpty()) {
            username = "Guest"; // Default if username is not provided
        }

        // Display score and username
        tvScore.setText("Your Score: " + score + "/100");
        tvUsername2.setText("Username: " + username);

        // Restart the quiz
        btnRestart.setOnClickListener(v -> {
            Intent intent = new Intent(activity_result.this, activity_quiz.class);
            startActivity(intent);
            finish();
        });

        // Share score on WhatsApp
        btnShare.setOnClickListener(v -> shareScoreOnWhatsApp());
    }

    private void shareScoreOnWhatsApp() {
        String message = username + " scored " + score + "/100 in the quiz! 🎉";
        Intent sendIntent = new Intent(Intent.ACTION_SEND);
        sendIntent.setType("text/plain");
        sendIntent.putExtra(Intent.EXTRA_TEXT, message);
        sendIntent.setPackage("com.whatsapp"); // Opens directly in WhatsApp

        try {
            startActivity(sendIntent);
        } catch (Exception e) {
            Toast.makeText(this, "WhatsApp is not installed!", Toast.LENGTH_SHORT).show();
        }
    }
}
