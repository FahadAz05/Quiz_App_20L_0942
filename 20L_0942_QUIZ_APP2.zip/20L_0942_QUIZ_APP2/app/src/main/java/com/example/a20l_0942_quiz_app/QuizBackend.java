package com.example.a20l_0942_quiz_app;

import java.util.ArrayList;
import java.util.List;

public class QuizBackend {
    private List<Question> questionList;
    private int currentIndex;
    private boolean[] answeredCorrectly; // To track which questions were answered correctly

    public QuizBackend() {
        questionList = new ArrayList<>();
        loadQuestions();
        currentIndex = 0;
        answeredCorrectly = new boolean[questionList.size()]; // Initialize tracking array
    }

    private void loadQuestions() {
        questionList.add(new Question("Who won the ICC Cricket World Cup 2019?",
                new String[]{"India", "England", "Australia", "New Zealand"}, 1));
        questionList.add(new Question("Who was the highest run-scorer in ICC Cricket World Cup 2019?",
                new String[]{"Rohit Sharma", "David Warner", "Kane Williamson", "Joe Root"}, 0));
        questionList.add(new Question("Who was the highest wicket-taker in ICC Cricket World Cup 2019?",
                new String[]{"Mitchell Starc", "Jasprit Bumrah", "Lockie Ferguson", "Mustafizur Rahman"}, 0));
        questionList.add(new Question("Where was the final of the ICC Cricket World Cup 2019 held?",
                new String[]{"Lord's", "MCG", "Eden Gardens", "Wankhede Stadium"}, 0));
        questionList.add(new Question("Which team scored the highest total in ICC Cricket World Cup 2019?",
                new String[]{"England", "India", "Australia", "New Zealand"}, 0));
        questionList.add(new Question("Who was named the Player of the Tournament in ICC Cricket World Cup 2019?",
                new String[]{"Ben Stokes", "Kane Williamson", "Virat Kohli", "Joe Root"}, 1));
        questionList.add(new Question("Which bowler took a hat-trick in ICC Cricket World Cup 2019?",
                new String[]{"Trent Boult", "Mitchell Starc", "Mohammad Shami", "Jasprit Bumrah"}, 2));
        questionList.add(new Question("Which match ended in a Super Over in ICC Cricket World Cup 2019?",
                new String[]{"India vs New Zealand", "England vs Australia", "England vs New Zealand", "Pakistan vs South Africa"}, 2));
        questionList.add(new Question("How many centuries did Rohit Sharma score in ICC Cricket World Cup 2019?",
                new String[]{"3", "4", "5", "6"}, 2));
        questionList.add(new Question("Which team did Pakistan defeat in their final group stage match?",
                new String[]{"England", "Bangladesh", "South Africa", "West Indies"}, 1));
    }

    public Question getCurrentQuestion() {
        return questionList.get(currentIndex);
    }

    public boolean checkAnswer(int selectedOption) {
        boolean isCorrect = questionList.get(currentIndex).getCorrectAnswerIndex() == selectedOption;

        // Store if the answer was correct to prevent re-scoring
        answeredCorrectly[currentIndex] = isCorrect;
        return isCorrect;
    }

    public boolean isAnsweredCorrectly(int index) {
        return answeredCorrectly[index];
    }

    public boolean nextQuestion() {
        if (currentIndex < questionList.size() - 1) {
            currentIndex++;
            return true;
        }
        return false;
    }

    public boolean prevQuestion() {
        if (currentIndex > 0) {
            currentIndex--;
            return true;
        }
        return false;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public int getTotalQuestions() {
        return questionList.size();
    }
}
